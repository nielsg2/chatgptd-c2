import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { MessageSquare, Brain, Settings, FileText } from 'lucide-react';
import ChatInterface from './ChatInterface';
import { useAppContext } from '@/contexts/AppContext';

const AppLayout: React.FC = () => {
  const { messages, memories, sessionStats } = useAppContext();
  const [activeTab, setActiveTab] = useState('chat');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            ChatGPTd - Local AI Assistant
          </h1>
          <p className="text-gray-600">
            Persistent memory, local file access, and OpenAI API integration
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <TabsContent value="chat" className="mt-0">
                <ChatInterface />
              </TabsContent>
              <TabsContent value="settings" className="mt-0">
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">API Configuration</h2>
                  <p className="text-gray-600 mb-4">
                    Configure your OpenAI API settings here. API keys are stored locally in your browser.
                  </p>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">API Key</label>
                      <input 
                        type="password" 
                        placeholder="sk-..." 
                        className="w-full p-2 border rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Model</label>
                      <select className="w-full p-2 border rounded-md">
                        <option>gpt-3.5-turbo</option>
                        <option>gpt-4</option>
                      </select>
                    </div>
                    <button className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
                      Save Configuration
                    </button>
                  </div>
                </Card>
              </TabsContent>
            </div>

            <div className="space-y-4">
              <Card className="p-4">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Session Stats
                </h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Messages:</span>
                    <span>{messages.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Memories:</span>
                    <span>{memories.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Session Time:</span>
                    <span>{Math.floor((Date.now() - sessionStats.sessionStartTime.getTime()) / 60000)}m</span>
                  </div>
                </div>
              </Card>
              
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Features</h3>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>✓ Persistent chat history</li>
                  <li>✓ Local storage</li>
                  <li>✓ OpenAI API integration</li>
                  <li>✓ Memory management</li>
                  <li>✓ File operations</li>
                </ul>
              </Card>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default AppLayout;