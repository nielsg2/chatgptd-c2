import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Bot, User, Trash2 } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

const ChatInterface: React.FC = () => {
  const { messages, addMessage, clearMessages, apiConfig } = useAppContext();
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    if (!apiConfig.apiKey) {
      toast({
        title: "API Key Required",
        description: "Please configure your OpenAI API key in Settings.",
        variant: "destructive"
      });
      return;
    }

    addMessage({
      content: input,
      role: 'user'
    });

    const userInput = input;
    setInput('');
    setIsLoading(true);

    try {
      // Simulate API call - in real implementation, use actual OpenAI API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const responses = [
        `I understand you said: "${userInput}". This is a demo response with persistent memory capabilities. Your message has been stored locally.`,
        `Thank you for your message about "${userInput}". I'm processing this with local memory storage and file access capabilities.`,
        `Received: "${userInput}". This ChatGPTd application maintains conversation history and can access local files for enhanced context.`,
        `Your input "${userInput}" has been processed. I can remember our conversation and help you manage local files and memories.`
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      addMessage({
        content: randomResponse,
        role: 'assistant'
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI response. Please check your API configuration.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    clearMessages();
    toast({
      title: "Chat Cleared",
      description: "All messages have been removed from this session."
    });
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            ChatGPTd - Local AI Assistant
          </CardTitle>
          {messages.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearChat}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4">
        <ScrollArea className="flex-1 h-96">
          <div className="space-y-4 p-4">
            {messages.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                <Bot className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium mb-2">Welcome to ChatGPTd</p>
                <p className="text-sm">
                  Start a conversation with your local AI assistant.
                  Your messages will be stored locally with persistent memory.
                </p>
              </div>
            )}
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex gap-2 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className="flex-shrink-0">
                    {message.role === 'user' ? (
                      <User className="h-6 w-6 p-1 bg-blue-500 text-white rounded-full" />
                    ) : (
                      <Bot className="h-6 w-6 p-1 bg-green-500 text-white rounded-full" />
                    )}
                  </div>
                  <div
                    className={`p-3 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="flex gap-2">
                  <Bot className="h-6 w-6 p-1 bg-green-500 text-white rounded-full animate-pulse" />
                  <div className="bg-gray-100 text-gray-900 p-3 rounded-lg">
                    <p className="text-sm">Thinking...</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            disabled={isLoading}
            className="flex-1"
          />
          <Button onClick={handleSend} disabled={isLoading || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ChatInterface;