import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { FileText, Upload, Download, Trash2, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FileItem {
  id: string;
  name: string;
  content: string;
  size: number;
  type: string;
  timestamp: Date;
}

const FileManager: React.FC = () => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);

  React.useEffect(() => {
    // Load files from localStorage
    const saved = localStorage.getItem('chatgptd-files');
    if (saved) {
      const parsed = JSON.parse(saved);
      setFiles(parsed.map((f: any) => ({
        ...f,
        timestamp: new Date(f.timestamp)
      })));
    }
  }, []);

  const saveFiles = (updatedFiles: FileItem[]) => {
    localStorage.setItem('chatgptd-files', JSON.stringify(updatedFiles));
    setFiles(updatedFiles);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const newFile: FileItem = {
        id: Date.now().toString(),
        name: file.name,
        content,
        size: file.size,
        type: file.type || 'text/plain',
        timestamp: new Date()
      };

      saveFiles([...files, newFile]);
      toast({
        title: "File Uploaded",
        description: `${file.name} has been saved locally.`
      });
    };
    reader.readAsText(file);
  };

  const downloadFile = (file: FileItem) => {
    const blob = new Blob([file.content], { type: file.type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const deleteFile = (id: string) => {
    saveFiles(files.filter(f => f.id !== id));
    if (selectedFile?.id === id) {
      setSelectedFile(null);
    }
    toast({
      title: "File Deleted",
      description: "File has been removed from local storage."
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const filteredFiles = files.filter(file =>
    file.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          File Manager ({files.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search files..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button
            onClick={() => fileInputRef.current?.click()}
            size="sm"
          >
            <Upload className="h-4 w-4 mr-1" />
            Upload
          </Button>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileUpload}
          style={{ display: 'none' }}
          accept=".txt,.md,.json,.csv,.log"
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {filteredFiles.map((file) => (
                <div
                  key={file.id}
                  className={`p-3 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                    selectedFile?.id === file.id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                  onClick={() => setSelectedFile(file)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-sm truncate">{file.name}</h4>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          downloadFile(file);
                        }}
                      >
                        <Download className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteFile(file.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">
                      {formatFileSize(file.size)}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {file.timestamp.toLocaleDateString()}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {selectedFile && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">{selectedFile.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <pre className="text-xs whitespace-pre-wrap">
                    {selectedFile.content.substring(0, 1000)}
                    {selectedFile.content.length > 1000 && '...'}
                  </pre>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FileManager;