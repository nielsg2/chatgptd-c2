import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/hooks/use-toast';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface MemoryItem {
  id: string;
  content: string;
  tags: string[];
  timestamp: Date;
  importance: 'low' | 'medium' | 'high';
}

interface ApiConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
  maxTokens: number;
  temperature: number;
}

interface AppContextType {
  // Chat state
  messages: Message[];
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  clearMessages: () => void;
  
  // Memory state
  memories: MemoryItem[];
  addMemory: (memory: Omit<MemoryItem, 'id' | 'timestamp'>) => void;
  removeMemory: (id: string) => void;
  
  // API config
  apiConfig: ApiConfig;
  updateApiConfig: (config: Partial<ApiConfig>) => void;
  
  // Session stats
  sessionStats: {
    messageCount: number;
    tokensUsed: number;
    sessionStartTime: Date;
  };
}

const defaultApiConfig: ApiConfig = {
  apiKey: '',
  baseUrl: 'https://api.openai.com/v1',
  model: 'gpt-3.5-turbo',
  maxTokens: 2048,
  temperature: 0.7
};

const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [apiConfig, setApiConfig] = useState<ApiConfig>(defaultApiConfig);
  const [sessionStats, setSessionStats] = useState({
    messageCount: 0,
    tokensUsed: 0,
    sessionStartTime: new Date()
  });

  // Load data from localStorage on mount
  useEffect(() => {
    const savedMessages = localStorage.getItem('chatgptd-messages');
    if (savedMessages) {
      const parsed = JSON.parse(savedMessages);
      setMessages(parsed.map((m: any) => ({
        ...m,
        timestamp: new Date(m.timestamp)
      })));
    }

    const savedMemories = localStorage.getItem('chatgptd-memories');
    if (savedMemories) {
      const parsed = JSON.parse(savedMemories);
      setMemories(parsed.map((m: any) => ({
        ...m,
        timestamp: new Date(m.timestamp)
      })));
    }

    const savedApiConfig = localStorage.getItem('chatgptd-api-config');
    if (savedApiConfig) {
      setApiConfig(JSON.parse(savedApiConfig));
    }
  }, []);

  // Save messages to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('chatgptd-messages', JSON.stringify(messages));
    setSessionStats(prev => ({ ...prev, messageCount: messages.length }));
  }, [messages]);

  // Save memories to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('chatgptd-memories', JSON.stringify(memories));
  }, [memories]);

  // Save API config to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('chatgptd-api-config', JSON.stringify(apiConfig));
  }, [apiConfig]);

  const addMessage = (message: Omit<Message, 'id' | 'timestamp'>) => {
    const newMessage: Message = {
      ...message,
      id: Date.now().toString(),
      timestamp: new Date()
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const clearMessages = () => {
    setMessages([]);
    localStorage.removeItem('chatgptd-messages');
  };

  const addMemory = (memory: Omit<MemoryItem, 'id' | 'timestamp'>) => {
    const newMemory: MemoryItem = {
      ...memory,
      id: Date.now().toString(),
      timestamp: new Date()
    };
    setMemories(prev => [...prev, newMemory]);
  };

  const removeMemory = (id: string) => {
    setMemories(prev => prev.filter(m => m.id !== id));
  };

  const updateApiConfig = (config: Partial<ApiConfig>) => {
    setApiConfig(prev => ({ ...prev, ...config }));
  };

  return (
    <AppContext.Provider
      value={{
        messages,
        addMessage,
        clearMessages,
        memories,
        addMemory,
        removeMemory,
        apiConfig,
        updateApiConfig,
        sessionStats
      }}
    >
      {children}
    </AppContext.Provider>
  );
};