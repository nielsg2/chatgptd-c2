# chatgptd v0.2.0

Integrated CogStack and project scaffold.