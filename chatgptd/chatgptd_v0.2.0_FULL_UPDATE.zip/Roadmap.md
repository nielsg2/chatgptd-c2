# Roadmap for chatgptd v0.2.0

- Integrate CogStack
- Build watcher daemon
