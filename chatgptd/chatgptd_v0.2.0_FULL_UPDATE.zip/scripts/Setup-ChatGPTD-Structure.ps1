# ====================================================
# Script: Setup-ChatGPTD-Structure.ps1
# Purpose: Recreate folder structure for chatgptd v0.2.0
# Author: Niels Goldstein (nielsg2)
# License: MIT License
# Version: v0.2.0
# ====================================================

$basePath = "C:\Users\nsgadm1\OneDrive\Code\chatgptd"

$folders = @(
    "cognition\CogStack\Daemon",
    "cognition\CogStack\Docs",
    "cognition\CogStack\Logs",
    "cognition\CogStack\MemoryStore",
    "cognition\CogStack\Prompts",
    "cognition\CogStack\Sandbox",
    "cognition\CogStack\Tests",
    "directives",
    "logs",
    "scripts"
)

foreach ($folder in $folders) {
    $fullPath = Join-Path $basePath $folder
    if (-not (Test-Path $fullPath)) {
        New-Item -Path $fullPath -ItemType Directory | Out-Null
        Write-Output "✅ Created $fullPath"
    } else {
        Write-Output "⏭️ Already exists: $fullPath"
    }
}