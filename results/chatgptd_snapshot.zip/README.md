# chatgptd

Modular AI orchestration daemon built for local memory, secure file handling, and persistent ChatGPT interaction. Part of the MurkyCloud ecosystem.

This repo adheres to the Vibe architecture: composable, memory-aware, and privacy-first.

