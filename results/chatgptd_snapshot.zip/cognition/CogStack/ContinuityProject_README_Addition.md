## 🔁 One-Liner for Memory Continuity Rehydration

Upload the continuity ZIP and execute the following in ChatGPT to restore state:

**Command:**
```
Rehydrate your memory from this continuity file that contains what you need to re-establish memory state.
```

This will:
- Extract the ZIP
- Reload `AI_Directives.txt`, `SESSION_FRAG`, and session settings
- Enter continuity-aware mode with current version tracking
