# chatgptd.ps1 - CogStack MVP Task Daemon
# Version: v0.1.3-FIXED
# License: MIT License
# Copyright (C) 2025 Niels Goldstein (nielsg2)
# Purpose: Polls Job_Queue folder for instructions and processes tasks automatically

$logFile = "C:\LOGS\chatgptd.log"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
"[$timestamp] 🟢 chatgptd started. PID: $PID" | Out-File -FilePath $logFile -Append

$queuePath = "$PSScriptRoot\Job_Queue"
$archivePath = "$PSScriptRoot\Archive"

if (-not (Test-Path $queuePath)) { New-Item -ItemType Directory -Path $queuePath | Out-Null }
if (-not (Test-Path $archivePath)) { New-Item -ItemType Directory -Path $archivePath | Out-Null }

Write-Output "🔄 chatgptd is running. Monitoring $queuePath..."

while ($true) {
    Get-ChildItem -Path $queuePath -Filter *.txt | ForEach-Object {
        $task = Get-Content $_.FullName -Raw
        $log = "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] ▶️ Task: $($_.Name)`n$task"
        $log | Out-File -FilePath $logFile -Append
        Move-Item $_.FullName -Destination "$archivePath\$($_.BaseName)_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
    }
    Start-Sleep -Seconds 5
}
