# ============================================
# Script: New-AITask.ps1
# Version: v0.1.0
# Purpose: Create a task file for chatgptd to process
# Author: Niels Goldstein (nielsg2)
# License: MIT License
# Repository: CogStack
# ============================================

param (
    [Parameter(Mandatory=$true)]
    [string]$Title,

    [Parameter(Mandatory=$true)]
    [string]$SourceFile,

    [Parameter(Mandatory=$true)]
    [string]$Instruction,

    [Parameter(Mandatory=$true)]
    [string]$OutputFile
)

$task = @{ 
    title       = $Title
    source      = $SourceFile
    instruction = $Instruction
    output      = $OutputFile
    created_at  = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    version     = "v0.1.0"
}

$taskJson = $task | ConvertTo-Json -Depth 3
$taskFileName = "20250619_231225_$($Title -replace '\W+', '_').json"
$taskPath = Join-Path -Path "$env:CODE_BASE\CogStack\Job_Queue" -ChildPath $taskFileName

# Ensure folder exists
if (-not (Test-Path -Path (Split-Path -Path $taskPath))) {
    New-Item -Path (Split-Path -Path $taskPath) -ItemType Directory -Force | Out-Null
}

# Write task JSON
$taskJson | Out-File -FilePath $taskPath -Encoding UTF8

Write-Host "✅ Task created: $taskPath"
