powershell
# chatgptd.ps1
# Daemon to monitor Job_Queue and execute basic tasks

$JobQueue = "$PSScriptRoot\Job_Queue"
$Archive = "$PSScriptRoot\Archive"
$LogFile = "C:\LOGS\chatgptd.log"

# Ensure log exists
if (!(Test-Path $LogFile)) {
    New-Item -ItemType File -Path $LogFile -Force | Out-Null
}

"[$(Get-Date -Format 'u')] 🔄 chatgptd is running. Monitoring $JobQueue..." | Out-File -FilePath $LogFile -Append

while ($true) {
    Get-ChildItem -Path $JobQueue -Filter *.json -ErrorAction SilentlyContinue | ForEach-Object {
        $taskFile = $_.FullName
        try {
            $task = Get-Content $taskFile | ConvertFrom-Json
            $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $logPrefix = "[$timestamp]"

            if ($task.task_type -eq "create_folder") {
                $folder = $task.folder_path
                if (!(Test-Path $folder)) {
                    New-Item -ItemType Directory -Path $folder -Force | Out-Null
                    "$logPrefix ✅ Created folder: $folder" | Out-File -FilePath $LogFile -Append
                } else {
                    "$logPrefix ⚠️ Folder already exists: $folder" | Out-File -FilePath $LogFile -Append
                }
            } else {
                "$logPrefix ❌ Unknown task type: $($task.task_type)" | Out-File -FilePath $LogFile -Append
            }

            # Archive task file
            $archivedFile = Join-Path $Archive ("$($_.BaseName)_$timestamp$($_.Extension)")
            Move-Item -Path $taskFile -Destination $archivedFile -Force
        }
        catch {
            "$logPrefix ❌ ERROR: $($_.Exception.Message)" | Out-File -FilePath $LogFile -Append
        }
    }

    Start-Sleep -Seconds 3
}
