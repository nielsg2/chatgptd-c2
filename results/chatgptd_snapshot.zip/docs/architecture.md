# 🧠 Architecture: chatgptd (with CogStack Integration)

## Overview
`chatgptd` is a modular, memory-aware orchestration daemon. It persists state, interacts with the OpenAI API, and supports intelligent workflows under local-first, Zero Trust principles. Now enhanced with **CogStack**, a strategic cognitive overlay for abstract reasoning and intent synthesis.

## Core Principles
- Local-first persistent storage
- Modular Vibe-native architecture
- Zero Trust AI integration
- Cognitive overlay via `CogStack`

## Module Overview
- `daemon/`: Orchestration controller
- `ai_bridge/`: OpenAI API interface
- `memory/`: PostgreSQL-backed memory engine
- `tasks/`: Task queue and YAML roadmap logic
- `ui/`: Local web/electron interface
- `api_gateway/`: REST API for automation
- `local_agent/`: Safe OS interfacing
- `filebot/`: File watcher and classifier
- `cognition/CogStack/`: Strategic abstraction engine
- `shared/`: Utility modules
- `docs/`: Documentation and specifications